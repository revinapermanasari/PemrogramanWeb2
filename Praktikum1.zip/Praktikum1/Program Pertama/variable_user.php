<?php
$Nama = "Revina Permanasari";
$Umur = 21;
$Berat = 42.0;

echo 'Nama : ' . $Nama;
echo '<br/>Umur : ' . $Umur.' Tahun';
echo '<br/>Berat : '.$Berat.' Kg'; 

echo '<br/>Hello ' . $Nama.' Apa kabar?';
?> 